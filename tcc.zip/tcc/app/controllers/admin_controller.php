<?php

require_once __DIR__. '/../crud/CrudAdministrador.php';
require_once __DIR__. '/../models/Administrador.php';

function perfil_admin(){
    session_start();
    $administrador = new CrudAdministrador();
    $admin = $administrador->getAdministrador($_SESSION['id_user']);
    include __DIR__."/../views/perfil_admin/informacoesperfil.php";
}
function listarAdmin(){
    session_start();
    $administrador = new CrudAdministrador();
    $admin = $administrador->getAdministrador($_SESSION['id_user']);
    include __DIR__."/../views/perfil_admin/informacoesperfil.php";
}


function cadastrarAdmin(){
    $crud = new CrudAdministrador();
    include '../views/cadastro_admin.php';
}

function salvarAdmin(){ //DANDO ERRO
    echo "<pre>";

    session_start();

    $usuario = new Administrador($_POST['nome'], $_POST['email'], $_POST['senha'],  $_POST['telefone'], $_POST['razao_social'], $_POST['nome_fantasia'], $_POST['cnpj']);
    $adm = new CrudAdministrador();
    $resultado = $adm->cadastrar($usuario);

    header("Location: http://localhost/tcc/app/controllers/produto_controller.php?acao=listar");
}


function editar(){
    @session_start();
    $crud = new CrudAdministrador();
    $id_admin = $_SESSION['id_user'];
    $admin = $crud->getAdministrador($id_admin);
    include '../views/perfil_admin/editaradmin.php';
}

function atualizar(){
    session_start();
    $crud = new CrudAdministrador();
    $admin = new Administrador($_POST['nome'], $_POST['email'], $_POST['senha'], $_POST['telefone'], $_POST['cnpj'], $_POST['razao_social'],$_POST['nome_fantasia'], $_POST['idusu']);
    $crud->editar($admin);

    header("Location: http://localhost/tcc/app/controllers/admin_controller.php?acao=listarAdmin");
}

function excluirAdmin(){
    session_start();

    $crud = new CrudAdministrador();
    $crud->excluir($_SESSION['id_user']);

    header("location: http://localhost/tcc/app/views/login.php") ;
}

//ROTAS
if (isset($_GET['acao']) && !empty($_GET['acao']) ) {

    if ($_GET['acao'] == 'cadastrar') {
        echo "chegou na rota";
        cadastrarAdmin();

    } elseif ($_GET['acao'] == 'salvar') {
        salvarAdmin();

    } elseif ($_GET['acao'] == 'perfil_admin') {
        perfil_admin();

    } elseif ($_GET['acao'] == 'editar') {
        editar();

    } elseif ($_GET['acao'] == 'atualizar') {
        atualizar();

    }elseif ($_GET['acao'] == 'excluir') {
        excluirAdmin();

    }elseif ($_GET['acao'] == 'listarAdmin') {
        listarAdmin();

    } else {
        require"http://localhost/tcc/app/views/cadastro_admin.php";
    }
}
