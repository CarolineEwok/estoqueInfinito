<?php require_once __DIR__."/indexperfil.php" ?>
    <link href="../../../assets/css/tilobotao.css" rel="stylesheet" />




    <div id="page-wrapper">
        <!-- Page Content -->

        <div id="page-inner" class="container">


            <div class="row">

                <div class="col-md-6 col-sm-12">
                    <div class="thumbnail">
                        <a href="#"><img class="card-img-top" src="../../assets/imagesSalvas/<?= $produto->imagem ?>" alt=""></a>

                    </div>
                    <h3 class="ui horizontal divider header"><i class="tag icon"></i>Descrição</h3>
                    <div class="panel panel-primary">

                        <div class="panel-body">
                            <p><?= $produto->descricao ?></p>
                        </div>


                    </div>
                </div>

                <div class="col-md-5" style="background: rgba(173, 216, 230, 0.55);">

                    <h2 style="color: #0a256a; margin-top: 20px"> <?= $produto->nome ?></h2>

                    <h3 style="color: #0a256a">*Referência: <?= $produto->referencia ?></h3>
                    <h3 style="color: #0a256a" > R$ <?= $produto->preco ?></h3>


                    </select>

                    <h3 style="color: #0a256a">*Quantidade em estoque: <?= $produto->estoque ?> </h3>

                    </select>

                    <h3 style="color: #0a256a; margin-top: 10px;" >*Loja:</h3>

                    <select class="form-control" style="width: 276px;">>
                        <option><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">---------</font></font></option>
                        <option><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Renner</font></font></option>
                        <option><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Marisa</font></font></option>
                        <option><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">C&A</font></font></option>
                        <option><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Vivara</font></font></option>
                    </select>

                    <h3 style="color: #0a256a; margin-top: 10px;">*Quantidade:</h3>
                    <input type="number" class="form-control" style="width: 276px;"><br>

                    <h3 style="color: #0a256a; margin-top: 1px;" >*Forma de pagamento:</h3>

                    <select class="form-control" style="width: 276px;">>
                        <option><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">---------</font></font></option>
                        <option><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">A vista</font></font></option>
                        <option><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">A prazo</font></font></option>

                    </select> <br>

                    <div style="margin-left: 0px;">
                        <h3 style="color: #0a256a;">*Disponibilidae do produto</h3><label class="switch">
                            <input type="checkbox" checked>
                            <span class="slider round"></span>
                        </label>
                    </div>

                    <button style="margin-left:20px;height: 52px;width: 202px;" id="botaovenda" class="ui button" onclick="alert('Seja bem vindo(a) ao Linha de Código.')" type="submit">Baixar do Estoque <i class="hand point down outline icon" style="
    padding-left: 15px;
"></i></i></button>
                    <button style="margin-left: 10px;background-color: #8f92a0;padding-bottom: 12px;border-bottom-width: 20px;width: 142px;height: 52px;" id="botaovenda" class="ui button" onclick="alert('Seja bem vindo(a) ao Linha de Código.')" type="submit">Editar  <i class="fa fa-edit" style=" width: 25px;
"></i></button>


                </div>
            </div>
        </div>
    </div>


<?php require_once "rodape.php"; ?>