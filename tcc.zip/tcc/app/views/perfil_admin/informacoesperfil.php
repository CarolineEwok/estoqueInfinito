<?php require_once "indexperfil.php"; ?>

<div id="page-wrapper">
    <div id="page-inner" class="container" style="margin-top: 0px;">


            <!-----AQUI FUNCIONALIDADE DO BOTÃO---

            href="http://localhost/tcc/app/controllers/admin_controller.php?acao=excluir&id_usuario=<?= $_SESSION['id_user'];?>"onclick="return confirm('Tem certeza que deseja excluir sua conta?');">

            AQUI FUNCIONALIDADE DO BOTÃO------>

        <div style="width: 900px; margin-left: 900px;"></div>  <div>
            <h3 style="width: 400px;"> Desativar / Ativar</h3><label class="switch">
                <input type="checkbox" checked="">
                <span class="slider round"></span>
            </label></div>


        <!-- Page Content -->


        <div class="col-md-6 col-sm-4" style="margin-left: 250px; margin-top: 100px">
            <div class="panel panel-primary" >
                <div class="panel-heading">
                    Informações
                </div>
                <div class="panel-footer">
                    Nome: <?= $admin->getNome(); ?>
                </div>

                <div class="panel-footer">
                    Email: <?= $admin->getEmail(); ?>
                </div>

                <div class="panel-footer">
                    Telefone: <?= $admin->getTelefone(); ?>
                </div>

                <div class="panel-footer">
                    CNPJ: <?= $admin->cnpj; ?>
                </div>

                <div class="panel-footer">
                    Razão Social: <?= $admin->razao_social; ?>
                </div>

                <div class="panel-footer">
                    Nome Fantasia: <?= $admin->nome_fantasia; ?>
                </div>


        <div class="panel-footer">
            <a class="btn btn-primary" href="?acao=editar" style="margin-left: 170px;"><i class="fa fa-edit "></i> Editar</a></div>
    </div>
    <!-- /. PAGE WRAPPER  -->
    </div>

    <?php require_once "rodape.php"; ?>

