<?php
if($_POST) {
    $senha          = $_POST['senha'];
    $senhaConfirma  = $_POST['senha_confirma'];
    if ($senha == "") {
        $mensagem = "<span class='aviso'><b>Aviso</b>: Senha não foi alterada!</span>";
    } else if ($senha == $senhaConfirma) {
        $mensagem = "<span class='sucesso'><b>Sucesso</b>: As senhas são iguais: ".$senha."</span>";
    } else {
        $mensagem = "<span class='erro'><b>Erro</b>: As senhas não conferem!</span>";
    }
    echo "<p id='mensagem'>".$mensagem."</p>";
}
?>


<link href="/assets/css/stilo_vali_senha.html" rel="stylesheet" />

<form name="form1" action="" method="post">
    <div>
        <label for="senha">Senha:</label>
        <br>
        <input type="password" name="senha" id="senha" placeholder="Informe sua senha" />
    </div>
    <br>
    <div>
        <label for="senha_confirma">Confirme sua senha:</label>
        <br>
        <input type="password" name="senha_confirma" id="senha_confirma" placeholder="Confirme sua senha" />
    </div>
    <br>
    <input type="submit" value="ENVIAR">
</form>
