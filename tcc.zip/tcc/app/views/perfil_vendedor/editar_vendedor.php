<?php  require_once "indexperfil.php"; ?>
    <!-- /. NAV SIDE  -->
    <div id="page-wrapper" >
        <div id="page-inner" class="container">


            <div class="ui text container form-sobre-fotos" >
                <div class="ui text container centered aligned" >
                    <h1 style="margin-left: 200px;">Editar Cadastro</h1>
                </div><br>
                <!--formulario de cadastro -->
                <form class="ui form" action="?acao=atualizar" method="post">
                    <!--NOME -->
                    <div class="field">
                        <label><font color="#636363" style="margin-left: 250px;">Nome Completo</font></label>
                        <input type="text" name="nome" value="<?= $vend->getNome(); ?>">
                    </div>

                    <!--EMAIL -->
                    <div class="field">
                        <label><font color="#363636" style="margin-left: 280px;">Email</font></label>
                        <input type="text" name="email" value="<?= $vend->getEmail(); ?>">
                    </div>

                    <!--TELEFONE -->
                    <div class="field">
                        <label><font color="#363636" style="margin-left: 270px;">Telefone</font></label>
                        <input type="text" name="telefone" value="<?= $vend->getTelefone(); ?>">
                    </div>

                    <!--CPF -->
                    <div class="field">
                        <label><font color="#363636" style="margin-left: 280px;">CPF</font></label>
                        <input type="text" name="cpf" value="<?= $vend->cpf; ?>">
                    </div>

                    <!--EMPRESA -->
                    <div class="field">
                        <label><font color="#363636" style="margin-left: 270px;">Empresa</font></label>
                        <input type="text" name="empresa" value="<?= $vend->empresa; ?>">
                    </div>
                    <!--senha -->
                    <div class="field">
                        <label><font color="#363636" style="margin-left: 280px;">Senha</font></label>
                        <input type="password" name="senha" value="<?= $vend->getSenha(); ?>">
                    </div>

                    <div class="field">
                        <label><font color="#363636" style="margin-left: 240px;">Confirmação de senha</font></label>
                        <input type="password" name="senha" value="<?= $vend->getSenha(); ?>">
                    </div>

                    <input type="hidden" value="<?= $vend->getIdUsuario() ?>" name="idusu"><br>
                    <input style="background-color: #0a256a; margin-left: 260px; color: white;" class="ui button" type="submit" name="enviar" onclick="return confirm('Usuário editado com sucesso!');">                </form>
            </div>

            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>

<?php require_once "rodape.php"; ?>